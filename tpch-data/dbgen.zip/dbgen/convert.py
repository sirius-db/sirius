

def convert_tbl_to_csv(filename, header):
    csv = open("".join([filename, ".csv"]), "w+")
    csv.write(header + "\n")
    tbl = open("".join([filename, ".tbl"]), "r")
    lines = tbl.readlines()
    for line in lines:
        length = len(line)
        line = line[:length - 2] + line[length-1:]
        line = line.replace(",","N")
        line = line.replace("|",",")
        csv.write(line)
    tbl.close()
    csv.close()


if __name__ == "__main__":
    for filename in ["customer", "lineitem", "nation", "orders", "part", "partsupp", "region", "supplier"]:
        if filename == "customer":
            header = "C_CUSTKEY,C_NAME,C_ADDRESS,C_NATIONKEY,C_PHONE,C_ACCTBAL,C_MKTSEGMENT,C_COMMENT"
        elif filename == "lineitem":
            header = "L_ORDERKEY,L_PARTKEY,L_SUPPKEY,L_LINENUMBER,L_QUANTITY,L_EXTENDEDPRICE,L_DISCOUNT,L_TAX,L_RETURNFLAG,L_LINESTATUS,L_SHIPDATE,L_COMMITDATE,L_RECEIPTDATE,L_SHIPINSTRUCT,L_SHIPMODE,L_COMMENT"
        elif filename == "nation":
            header = "N_NATIONKEY,N_NAME,N_REGIONKEY,N_COMMENT"
        elif filename == "orders":
            header = "O_ORDERKEY,O_CUSTKEY,O_ORDERSTATUS,O_TOTALPRICE,O_ORDERDATE,O_ORDERPRIORITY,O_CLERK,O_SHIPPRIORITY,O_COMMENT"
        elif filename == "part":
            header = "P_PARTKEY,P_NAME,P_MFGR,P_BRAND,P_TYPE,P_SIZE,P_CONTAINER,P_RETAILPRICE,P_COMMENT"
        elif filename == "partsupp":
            header = "PS_PARTKEY,PS_SUPPKEY,PS_AVAILQTY,PS_SUPPLYCOST,PS_COMMENT"
        elif filename == "region":
            header = "R_REGIONKEY,R_NAME,R_COMMENT"
        elif filename == "supplier":
            header = "S_SUPPKEY,S_NAME,S_ADDRESS,S_NATIONKEY,S_PHONE,S_ACCTBAL,S_COMMENT"
        convert_tbl_to_csv(filename, header)