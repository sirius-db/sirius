set -x

while getopts s: flag
do
    case "${flag}" in
        s) scale=${OPTARG};;
    esac
done

rm -rf *.tbl
rm -rf *.csv
./dbgen -s $scale

python convert.py
